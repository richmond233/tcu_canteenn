<?php

$con = mysqli_connect("localhost","root","","tcu_canteen");

?>
